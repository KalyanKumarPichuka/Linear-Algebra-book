package com.kalyan.watson;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import com.ibm.watson.developer_cloud.speech_to_text.v1.SpeechToText;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.RecognizeOptions;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.SpeechModel;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.SpeechResults;
import com.ibm.watson.developer_cloud.speech_to_text.v1.websocket.BaseRecognizeCallback;

public class SpeechToTextConversion {

	//InputStream in = this.getClass().getClassLoader().getResourceAsStream("/audiofiles/audio-file.flac");
	
	public static void main(String[] args) {
		
		
		
		SpeechToText service = new SpeechToText();
		service.setUsernameAndPassword("73409e63-3cdb-41e6-bf9c-9b709b7927e3", "Rgftd6pt23UW");
/*		List<SpeechModel> models = service.getModels().execute();
		System.out.println(models);*/
		SpeechModel model = service.getModel("en-US_BroadbandModel").execute();
		System.out.println(model);
		
		
		
		RecognizeOptions options = new RecognizeOptions.Builder()
		  .model("en-US_BroadbandModel").contentType("audio/flac")
		  .interimResults(false).maxAlternatives(3)   //chnaging to false and seeing the result
		  .keywords(new String[]{"colorado", "tornado", "tornadoes"})
		  .keywordsThreshold(0.5).build();

		BaseRecognizeCallback callback = new BaseRecognizeCallback() {
		  @Override
		  public void onTranscription(SpeechResults speechResults) {
		    System.out.println(speechResults);
		  }

		  @Override
		  public void onDisconnected() {
		    System.exit(0);
		  }
		};

		try {
		  service.recognizeUsingWebSocket
		    (new FileInputStream("C:\\Users\\kalyan\\Downloads\\IBM Watson\\audio-file.flac"), options, callback);
		}
		catch (FileNotFoundException e) {
		  e.printStackTrace();
		}

	}

}
